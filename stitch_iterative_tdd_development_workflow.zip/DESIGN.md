---
name: SpecForge Studio
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00885d'
  on-tertiary-container: '#000703'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies an authoritative, precision-engineered technical workspace tailored for drafting, validating, and governing engineering curricula and technical specifications. It balances the rigor of academic accreditation with the fluid ergonomic demands of modern IDEs and developer consoles. 

The aesthetic is grounded in a hybrid of **Corporate / Modern** precision and **Technical Minimalism**. The interface prioritizes high-density data visualization, linear flow, and structural clarity over ornamental flair. Every visual cue serves document verification, diff tracking, and multi-tiered governance (Author, Reviewer, and Head of Department roles).

### Key Brand Tenets
- **Architectural Precision:** Pixel-sharp structure, low-contrast bounding lines, and disciplined alignment reflect institutional credibility and academic rigor.
- **Cognitive Quiet:** Dense information architectures require muted backgrounds, deliberate contrast ratios, and purposeful semantic color coding to prevent review fatigue.
- **Workflow State Clarity:** Explicit visual demarcations distinguish between draft specifications, pending peer reviews, automated accreditation checks, and executive departmental approvals.

## Colors

The system uses a dark-first color strategy optimized for long working sessions involving deep document trees, markdown editors, and schema parsers.

### Palette Architecture
- **Primary (`#6366F1` - Electric Indigo):** Anchors core navigational waypoints, primary actions, focused form states, and active branch markers.
- **Secondary (`#06B6D4` - Cyan Accent):** Reserved for real-time telemetry, automated linting signals, telemetry diff highlights, and reviewer suggestion callouts.
- **Tertiary (`#10B981` - Mint Emerald):** Governs approval gates, accreditation passes, verified prerequisites, and Head of Department sign-offs.
- **Neutral (`#0F172A` - Slate Neutral):** Provides a layered foundation ranging from deep navy/slate canvas backdrops (`#090D16`) to elevated workspace surfaces (`#1E293B`) and crisp low-contrast dividing lines (`#334155`).

### Functional Status & Governance Tones
- **Author Drafts:** Indigo-tinted slate markers.
- **Reviewer Deliberation:** Amber (`#F59E0B`) for inline comments and pending modifications.
- **HOD Executive Veto/Blocker:** Crimson (`#EF4444`) for accreditation schema violations or blocked syllabus approvals.

## Typography

The typographic hierarchy pairs the geometric neutrality and neutral legibility of **Geist** for documentation and conversational reviews with the structural precision of **JetBrains Mono** for course metadata, schema tokens, credit distributions, and diff inspection.

### Usage Standards
- **Geist (Headlines & Body):** Handles dynamic prose, syllabus outcome documentation, lecture modules, and governance discourse. High x-height ensures readability across dense multi-column splits.
- **JetBrains Mono (Labels & Telemetry):** Strict monospaced treatment across course codes (e.g., `CS-4021`), accreditation criteria tags (e.g., `ABET-EAC-3b`), timestamps, commit hashes, and role badges.
- **Tabular Figures:** All numeric displays—such as contact hours, credit points, and grading weightings—must use open font feature flags enabling tabular figures (`tnum`).

## Layout & Spacing

The layout utilizes a continuous high-density workspace model modeled around 3-pane workbench layouts common in enterprise software engineering suites:

1. **Tree/Taxonomy Explorer (Left Rail):** Collapsible file and module explorer fixed between 240px and 300px.
2. **Editor & Course Architecture Canvas (Center):** Fluid-width core canvas structured around an internal 12-column sub-grid with tight 16px gutters.
3. **Contextual Review & Audit Inspector (Right Rail):** Fixed 340px workbench panel housing real-time diffs, HOD approval queues, and syllabus lint errors.

### Viewport Adaptation & Breakpoints
- **Desktop (≥ 1280px):** Full 3-pane workbench active simultaneously. Outer margins locked to `margin-lg` (32px).
- **Tablet (768px – 1279px):** Inspector slides into an overlay drawer. Center canvas retains priority. Margins downscale to `margin` (24px).
- **Mobile (< 768px):** Single-column stack. Tree explorer and inspector transform into dedicated full-bleed modal panels. Margins drop to `margin-sm` (16px), with component gaps condensed to `space-sm` (8px) and `space-md` (12px).

## Elevation & Depth

Visual hierarchy within this design system relies on **Tonal Layering** accompanied by **Subtle Low-Contrast Outlines**, strictly rejecting heavy drop shadows or skeuomorphic blurs.

### Surface Tiers
- **Tier 0 (Base Canvas - `#090D16`):** The outermost viewport frame and workbench gutter regions.
- **Tier 1 (Surface Panel - `#0F172A`):** The primary canvas for course editing, module containers, and active syllabus sections.
- **Tier 2 (Elevated Component - `#1E293B`):** Inputs, interactive list items, card modules, and sticky sub-headers.
- **Tier 3 (Overlay / Flyout - `#334155`):** Popovers, code inspection tooltips, role delegation dropdowns, and diff floating toolbars.

### Edge Definition
Every elevated surface tier is bounded by a crisp 1px stroke (`rgba(148, 163, 184, 0.12)` in dark mode). Diff blocks or reviewer comments receive an additional left-hand edge accent in secondary cyan or tertiary emerald to confirm contextual lineage without physical elevation changes.

## Shapes

The system adheres to an angular, compact geometry (`roundedness: 1`). Soft 4px (`0.25rem`) standard corner radii communicate engineering discipline and maximize internal pixel space for dense content matrices.

### Token Mapping
- **Input Fields, Badges, Buttons, and Table Rows:** 4px (`rounded-sm`).
- **Cards, Code Panels, Diff Blocks, and Dialog Shells:** 8px (`rounded-lg`).
- **Flyout Modals & Root Context Menus:** 12px (`rounded-xl`).
- **Full Pills (`rounded-full`):** Explicitly reserved only for presence indicators and status dots.

## Components

### Buttons & Action Triggers
- **Primary Action (Publish, Approve, Sign-off):** Deep indigo fill (`#6366F1`) with crisp white label text, 0.25rem radius, height 32px (compact) or 38px (regular). Hover shifts to `#4F46E5`.
- **Secondary (Add Module, Run Linter):** Dark slate surface (`#1E293B`) with a 1px border (`#334155`) and cyan accent hover highlights.
- **Destructive/Reject (HOD Rejection):** Subtle crimson background tint with a high-contrast crimson text and border (`#EF4444`).

### Chips, Pills & Status Badges
- Displayed using `label-md` in `JetBrains Mono` with uppercase transformations.
- **Author Draft:** Slate background with muted slate-gray text.
- **In Review:** Amber tint background (`rgba(245, 158, 11, 0.12)`) with bright amber border and text.
- **HOD Approved:** Emerald tint (`rgba(16, 185, 129, 0.12)`) with solid mint text.

### Form Inputs & Syllabus Modifiers
- Background filled with Tier 1 Slate (`#0F172A`), enclosed in a 1px line (`#334155`).
- Focus state eliminates standard browser glows in favor of a crisp 1px primary electric indigo stroke coupled with an inner hairline highlight.
- Monospaced inputs for course code, prerequisites, contact hours, and credit ratios.

### Course Spec Cards & Outline Nodes
- Structural cards feature a left 3px border denoting node status: grey for untouched, cyan for modified by Author, amber for Reviewer note present.
- Header bands contain module indices, lecture unit titles, and inline accreditation tags.

### Specialized Workflow Components
- **Diff Timeline Node:** Renders side-by-side or unified inline diffs of lecture learning outcomes, highlighting added competencies in muted emerald and removed prerequisites in muted rose.
- **Workflow State Stepper:** A compact horizontal ribbon indicating the course life cycle (Authoring → Peer Review → Board of Studies → HOD Approval) with timestamped monospaced avatar nodes.
- **Accreditation Mapping Matrix:** Dense data table with checkbox grid matrices correlating course outcomes (COs) to program educational objectives (PEOs).